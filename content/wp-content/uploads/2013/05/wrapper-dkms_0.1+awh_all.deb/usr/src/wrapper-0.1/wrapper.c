#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/perf_event.h>
#include <linux/kprobes.h>

static char *function_name = "perf_swevent_init";

static int wrapper(struct kprobe *p, struct pt_regs *regs)
{
	struct perf_event *event = (struct perf_event *)(regs->di);
	event->attr.config &= INT_MAX;
	return 0;
}

static struct kprobe kp = {
	.pre_handler = wrapper,
};

static int __init wrapper_init(void)
{
	int ret;

	kp.symbol_name = function_name;

	ret = register_kprobe(&kp);
	if (ret < 0) {
		printk(KERN_INFO "%s: error %d\n", __func__, ret);
		return ret;
	}
	return 0;
}

static void __exit wrapper_exit(void)
{
	unregister_kprobe(&kp);
}

module_init(wrapper_init)
module_exit(wrapper_exit)

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Andrea Righi <andrea@betterlinux.com>");
MODULE_DESCRIPTION("Fix perf bug CVE-2013-2094");
