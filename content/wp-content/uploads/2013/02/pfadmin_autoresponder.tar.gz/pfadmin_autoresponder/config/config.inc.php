<?php

$rcmail_config['db_pfadmin_autoresponder_dsn'] = 'mysql://USER:PASSWORD@localhost/DBNAME';
$rcmail_config['vac_domain']='autoreply.domain.com';

?>
